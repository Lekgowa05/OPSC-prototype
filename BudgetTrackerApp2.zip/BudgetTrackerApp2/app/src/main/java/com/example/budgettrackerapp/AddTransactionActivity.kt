package com.example.budgettrackerapp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import android.app.DatePickerDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.budgettracker.data.Transaction
import com.example.budgettracker.databinding.ActivityAddTransactionBinding
import com.example.budgettracker.ui.TransactionViewModel
import com.google.android.material.button.MaterialButton
import java.util.*

class AddTransactionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddTransactionBinding
    private lateinit var viewModel: TransactionViewModel
    private var transactionId: Int = -1
    private var selectedDate: Date = Date()
    private lateinit var typeGroup: RadioGroup
    private lateinit var categorySpinner: Spinner
    private lateinit var etAmount: EditText
    private lateinit var etDescription: EditText
    private lateinit var btnDate: MaterialButton
    private lateinit var btnSave: Button
    private lateinit var btnDelete: Button

    private val categories = listOf("Food", "Transport", "Shopping", "Entertainment", "Bills", "Salary", "Other")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddTransactionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Add Transaction"

        viewModel = ViewModelProvider(this)[TransactionViewModel::class.java]

        initViews()
        setupDatePicker()
        transactionId = intent.getIntExtra("transaction_id", -1)

        if (transactionId != -1) {
            title = "Edit Transaction"
            loadTransaction()
            btnDelete.visibility = Button.VISIBLE
            btnDelete.setOnClickListener { deleteTransaction() }
        } else {
            btnDelete.visibility = Button.GONE
        }

        btnSave.setOnClickListener { saveTransaction() }
    }

    private fun initViews() {
        typeGroup = binding.rgType
        categorySpinner = binding.spinnerCategory
        etAmount = binding.etAmount
        etDescription = binding.etDescription
        btnDate = binding.btnDate
        btnSave = binding.btnSave
        btnDelete = binding.btnDelete

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categories)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter

        // Update category spinner based on type selection
        typeGroup.setOnCheckedChangeListener { _, checkedId ->
            if (checkedId == R.id.rbIncome) {
                // Income categories could be filtered, but we keep same for simplicity
            }
        }
    }

    private fun setupDatePicker() {
        btnDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            calendar.time = selectedDate
            DatePickerDialog(
                this,
                { _, year, month, dayOfMonth ->
                    val selectedCal = Calendar.getInstance()
                    selectedCal.set(year, month, dayOfMonth)
                    selectedDate = selectedCal.time
                    updateDateButtonText()
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        }
        updateDateButtonText()
    }

    private fun updateDateButtonText() {
        val format = java.text.SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        btnDate.text = format.format(selectedDate)
    }

    private fun loadTransaction() {
        lifecycleScope.launch(Dispatchers.IO) {
            val transaction = viewModel.getTransactionById(transactionId)
            if (transaction != null) {
                runOnUiThread {
                    etAmount.setText(transaction.amount.toString())
                    etDescription.setText(transaction.description)
                    selectedDate = transaction.date
                    updateDateButtonText()

                    if (transaction.type == "Income") {
                        binding.rbIncome.isChecked = true
                    } else {
                        binding.rbExpense.isChecked = true
                    }

                    val categoryIndex = categories.indexOf(transaction.category)
                    if (categoryIndex >= 0) {
                        categorySpinner.setSelection(categoryIndex)
                    }
                }
            }
        }
    }

    private fun saveTransaction() {
        val amountText = etAmount.text.toString()
        val description = etDescription.text.toString().trim()

        if (amountText.isEmpty()) {
            etAmount.error = "Amount required"
            return
        }
        if (description.isEmpty()) {
            etDescription.error = "Description required"
            return
        }

        val amount = amountText.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            etAmount.error = "Enter valid amount"
            return
        }

        val type = if (binding.rbIncome.isChecked) "Income" else "Expense"
        val category = categories[categorySpinner.selectedItemPosition]

        val transaction = Transaction(
            id = if (transactionId != -1) transactionId else 0,
            amount = amount,
            type = type,
            category = category,
            description = description,
            date = selectedDate
        )

        if (transactionId == -1) {
            viewModel.insert(transaction)
            Toast.makeText(this, "Transaction added", Toast.LENGTH_SHORT).show()
        } else {
            viewModel.update(transaction)
            Toast.makeText(this, "Transaction updated", Toast.LENGTH_SHORT).show()
        }
        finish()
    }

    private fun deleteTransaction() {
        lifecycleScope.launch(Dispatchers.IO) {
            val transaction = viewModel.getTransactionById(transactionId)
            transaction?.let {
                viewModel.delete(it)
                runOnUiThread {
                    Toast.makeText(this@AddTransactionActivity, "Deleted", Toast.LENGTH_SHORT).show()
                    finish()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}