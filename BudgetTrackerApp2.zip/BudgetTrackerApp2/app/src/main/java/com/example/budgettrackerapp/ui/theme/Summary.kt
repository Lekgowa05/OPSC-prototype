package com.example.budgettrackerapp.ui.theme

data class Summary(
    val totalIncome: Double,
    val totalExpense: Double,
    val balance: Double
)