package com.example.budgettracker.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.viewModelScope
import com.example.budgettracker.data.BudgetDatabase
import com.example.budgettracker.data.Repository
import com.example.budgettracker.data.Transaction
import kotlinx.coroutines.launch

class TransactionViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: Repository
    val allTransactions: LiveData<List<Transaction>>
    val summary: LiveData<Summary>

    init {
        val dao = BudgetDatabase.getDatabase(application).transactionDao()
        repository = Repository(dao)
        allTransactions = dao.getAllTransactions().asLiveData(viewModelScope.coroutineContext)

        // Calculate summary
        val mediator = MediatorLiveData<Summary>()
        summary = mediator
        mediator.addSource(allTransactions) { transactions ->
            var totalIncome = 0.0
            var totalExpense = 0.0
            transactions?.forEach { transaction ->
                if (transaction.type == "Income") {
                    totalIncome += transaction.amount
                } else {
                    totalExpense += transaction.amount
                }
            }
            mediator.value = Summary(totalIncome, totalExpense, totalIncome - totalExpense)
        }
    }

    fun insert(transaction: Transaction) = viewModelScope.launch {
        repository.insert(transaction)
    }

    fun update(transaction: Transaction) = viewModelScope.launch {
        repository.update(transaction)
    }

    fun delete(transaction: Transaction) = viewModelScope.launch {
        repository.delete(transaction)
    }

    suspend fun getTransactionById(id: Int): Transaction? = repository.getTransactionById(id)
}

// Extension function for Flow -> LiveData
fun <T> kotlinx.coroutines.flow.Flow<T>.asLiveData(dispatcher: kotlin.coroutines.CoroutineContext): LiveData<T> =
    androidx.lifecycle.asLiveData(context = kotlinx.coroutines.CoroutineScope(dispatcher).coroutineContext)